# doctor-simulator
Jackson-Reed High School java project by Damian and Andrei
please find extensions for idea in DoctorSimulator.java

Copied:
/**
 * A NOT SO ACCURATE DOCTOR SIMULATOR, TRY TO KEEP YOUR PATIENT ALIVE
 * @author Damian, Andrei
 * 
 * SUGGESTIONS FOR EXTENSIONS: 
 *  Change choiceEQ ifs nest using case switch to make it neater
 *  Add an enum class to represents the items and action choices for the player, currently represented by int
 *  Make the option to have multiple patients to manage at the same time (add another Patient type and dialogues)
 *  Expand Events.java and make other random events (ex: heart attack)
 *  Have another aspect for Patient.java (ex: pain level)
 *  More graphics for data representation or more (use window.java)
 *  Modify the graphics so it looks prettier
 *  Patient subclass
 * 
 *  PLEASE IGNORE EXTENSIONS Draw.java, DrawListener.java, StdDraw.java, and window.java. 
 */
